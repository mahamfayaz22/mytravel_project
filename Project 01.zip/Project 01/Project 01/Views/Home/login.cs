﻿//namespace Project_01.Views.Home
//{
//    public class login
//    {
//        <!DOCTYPE html>
//<html lang = "en" >
//< head >
//  < meta charset="UTF-8">
//  <meta name = "viewport" content="width=device-width, initial-scale=1.0">
//  <title>Login Form</title>
//  <style>
//    * {
//        margin: 0;
//        padding: 0;
//        }
//    .cenn {
//      font-family: Arial, sans-serif;
//      background-color: #f4f4f9;
//      margin: 0;
//      padding: 0;
//      display: flex;
//      justify-content: center;
//      align-items: center;
//      height: 100vh;

//    }

//    .login-container {
//      background-color: #fff;
//      padding: 20px;
//      border-radius: 8px;
//      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
//    width: 300px;
//      padding-right: 40px;
//    }

//    .login - container h2 {
//      text-align: center;
//margin - bottom: 20px;
//color: #333;
//    }

//    .login - container label {
//      display: block;
//margin - bottom: 5px;
//font - weight: bold;
//    }

//    .login - container input[type = "text"],
//    .login - container input[type = "password"] {
//width: 100 %;
//padding: 10px;
//    margin - bottom: 15px;
//border: 1px solid #ccc;
//      border - radius: 4px;
//}

//    .login - container button {
//      width: 100 %;
//padding: 10px;
//margin - left:12px;
//background - color: #4CAF50;
//      color: white;
//border: none;
//border - radius: 4px;
//font - size: 16px;
//cursor: pointer;
//    }

//    .login - container button: hover {
//    background - color: #45a049;
//    }

//    .login - container.forgot - password {
//    text - align: center;
//    margin - top: 10px;
//}

//    .login - container.forgot - password a {
//      text-decoration: none;
//color: #007BFF;
//      font - size: 14px;
//    }

//    .login - container.forgot - password a: hover {
//    text - decoration: underline;
//}
//  </ style >
//</ head >
//< body >
//< div class= "cenn" >
//  < div class= "login-container" >
//    < h2 > Login </ h2 >
//    < form action = "#" method = "post" >
//      < label for= "username" > Username:</ label >
//      < input type = "text" id = "username" name = "username" placeholder = "Enter your username" required >

//      < label for= "password" > Password:</ label >
//      < input type = "password" id = "password" name = "password" placeholder = "Enter your password" required >

//      < button type = "submit" > Login </ button >
//    </ form >
//    < div class= "forgot-password" >
//      < a href = "#" > Forgot Password ?</ a >
//    </ div >
//  </ div >
//</ div >
//</ body >
//</ html >
//    }
//}
